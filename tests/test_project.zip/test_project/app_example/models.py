from django.db import models

class Orders(models.Model):
    pass

class Shipments(models.Model):
    pass

class Customers(models.Model):
    pass

